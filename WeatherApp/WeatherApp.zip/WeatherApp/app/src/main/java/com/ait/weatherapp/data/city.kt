package com.ait.weatherapp.data

data class city(val name: String, val description : String?)